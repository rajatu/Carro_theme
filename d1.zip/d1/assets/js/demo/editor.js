$(function() {
    /* SummerNote */
    if($(".editor").length > 0) 
        $(".editor").summernote();
    /* // SummerNote */
});
