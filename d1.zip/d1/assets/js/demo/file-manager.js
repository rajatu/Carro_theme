$(function() {
	// elFinder initialization
     var elf = $('#elfinder').elfinder({
        // lang: 'ru',             // language (OPTIONAL)
        url : '../assets/js/plugins/elfinder/php/connector.php'  // connector URL (REQUIRED)
    }).elfinder('instance');

});
