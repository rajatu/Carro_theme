$(function() {
    /* Back buttons */
    if($(".btn").length > 0) {
        $(".btn").on('click', function () {
        	location.href = '?page=index';
        });
    }
    /* // Back buttons */
});
